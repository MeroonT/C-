// Computer Programming, XB_40011, Fall 2018
// Vrije Universiteit, Amsterdam
//
// (Ungraded) Assignment 2.1 "Collatz"
// 
// Get this assignment accepted by your teaching assistant!
// (Do not submit this assignment to Canvas.)
//
// Student name   : Meroon tesfai keleta sengal   
// Student number : 22646691
// VUnet-id       : mel450
//
// Fill in your details above,
// then enter your code below this header.
//
#include <iostream>
using namespace std;

int main() 
{
  int number;
  
  cout << "Enter the first number of the sequence: ";
  cin >> number;
  cout << number;
  
  while (number > 1) 
  {
    if (number % 2 == 0) {
      number = (number / 2);
    }
    else {
      number = ((3 * number) + 1);
    }
  cout << " " << number;
  }
  
  return 0;
}